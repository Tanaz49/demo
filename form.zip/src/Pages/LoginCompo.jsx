import React, { useState } from 'react';
import side_img from './img.jpg';

const StepForm = () => {
  const [step, setStep] = useState(1);

  // Function to move to the next step
  const nextStep = () => {
    setStep(step + 1);
  };

  // Function to move to the previous step (optional)
  const prevStep = () => {
    setStep(step - 1);
  };

  // Step 1 Form
  const Step1 = () => (

    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Welcome to DearmLink</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
           
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>

  );

  // Step 2 Form
  const Step2 = () => (
    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Personal Information</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" placeholder="Enter Your Phone Number"/>
                </div>
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <input type="date" id="birthday" placeholder="Enter Your Birthday"/>
                </div>
                <div class="form-group">
                    <label for="talent">Is talent readable or not readable?</label>
                    <select id="talent">
                        <option value="">Select</option>
                        <option value="readable">Readable</option>
                        <option value="not-readable">Not Readable</option>
                    </select>
                </div>
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>
    
  );

  // Step 3 Form
  const Step3 = () => (
    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Emergency Contact Details</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" placeholder="Enter Your Phone Number"/>
                </div>
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <input type="date" id="birthday" placeholder="Enter Your Birthday"/>
                </div>
                <div class="form-group">
                    <label for="talent">Is talent readable or not readable?</label>
                    <select id="talent">
                        <option value="">Select</option>
                        <option value="readable">Readable</option>
                        <option value="not-readable">Not Readable</option>
                    </select>
                </div>
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>
  );
  const Step4 = () => (
    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Select Couach</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" placeholder="Enter Your Phone Number"/>
                </div>
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <input type="date" id="birthday" placeholder="Enter Your Birthday"/>
                </div>
                <div class="form-group">
                    <label for="talent">Is talent readable or not readable?</label>
                    <select id="talent">
                        <option value="">Select</option>
                        <option value="readable">Readable</option>
                        <option value="not-readable">Not Readable</option>
                    </select>
                </div>
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>
  );
  const Step5 = () => (
    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Register as job Couach</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" placeholder="Enter Your Phone Number"/>
                </div>
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <input type="date" id="birthday" placeholder="Enter Your Birthday"/>
                </div>
                <div class="form-group">
                    <label for="talent">Is talent readable or not readable?</label>
                    <select id="talent">
                        <option value="">Select</option>
                        <option value="readable">Readable</option>
                        <option value="not-readable">Not Readable</option>
                    </select>
                </div>
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>
  );
  const Step6 = () => (
    <div className='container'>
         <div class="illustration">
            <img src={side_img} alt="Illustration of a person and a trainee" />
        </div>
         <div class="form-container">
            <h2>Register as job Couach</h2>
            <form>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" placeholder="Enter Your First and Last Name"/>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="Enter Your Email"/>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" placeholder="Enter Your Phone Number"/>
                </div>
                <div class="form-group">
                    <label for="birthday">Birthday</label>
                    <input type="date" id="birthday" placeholder="Enter Your Birthday"/>
                </div>
                <div class="form-group">
                    <label for="talent">Is talent readable or not readable?</label>
                    <select id="talent">
                        <option value="">Select</option>
                        <option value="readable">Readable</option>
                        <option value="not-readable">Not Readable</option>
                    </select>
                </div>
                <button type="button" onClick={nextStep}>Next</button>
                {/* <button type="submit">Next</button> */}
            </form>
        </div>
      {/* <h2>Step 1: Basic Information</h2>
      <form>
        <label>
          Name:
          <input type="text" name="name" />
        </label>
        <br />
        <label>
          Email:
          <input type="email" name="email" />
        </label>
        <br />
        <button type="button" onClick={nextStep}>Next</button>
      </form> */}
    </div>
  );

  // Render the form based on the current step
  switch(step) {
    case 1:
      return <Step1 />;
    case 2:
      return <Step2 />;
    case 3:
      return <Step3 />;
    default:
      return <Step1 />;
  }
};

export default StepForm;





// import React from 'react';
// import { Link, useNavigate } from 'react-router-dom';

// const LoginCompo = () => {
//     const navigate = useNavigate();

//     const checklogin = (e)=>{
//         console.log("called");
//         e.preventDefault()
//         navigate("/admin/dashboard")
//     }
//     return (
//         <>
//             <div className="container mt-5">
//                 <div className="row">
//                     <div className="col-lg-4 offset-lg-4">
//                         <div className="card">
//                             <div className="card-header text-center">Login</div>
//                             {/* <div className="card-body">  </div>    */}
//                             <div className="card-body">
//                                 <form onSubmit={checklogin}>
//                                     <div className="row">
//                                         <div className="col">
//                                             <input type="text" placeholder='Enter User Name' className='form-control' name="uname" required />
//                                         </div>

//                                     </div>
//                                     <div className="row mt-3">
//                                         <div className="col">
//                                             <input className='form-control' placeholder='Enter your Password' type="password"  name="pass" required />
//                                         </div>

//                                     </div>
//                                     <div className="row mt-3">
//                                         <div className="col text-center">
//                                             <input type="submit" className='btn btn-info' /> &nbsp;
//                                             <input type="reset" className='btn btn-warning' />
//                                         </div>

//                                     </div>
//                                 </form>
//                                 <div className="row mt-3">
//                                     <div className="col text-center">
//                                         <Link to="/signup">Click here to create new account</Link>
//                                     </div>
//                                 </div>
                               
//                             </div>

//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </>
//     );
// };

// export default LoginCompo;