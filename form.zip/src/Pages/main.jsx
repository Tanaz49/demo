import React from 'react';
import HeaderCompo from './../Components/HeaderFile';
import { Outlet } from 'react-router-dom';

const Main = () => {
    return (
        <>
          {/* <HeaderCompo/> */}
          <h2>Main page</h2>
          {/* <Outlet></Outlet>   */}
        </>
    );
};

export default Main;