import React, { lazy, Suspense } from 'react';
import { createBrowserRouter, Link, Outlet } from "react-router-dom";
import MainPage from "./../Pages/main";
import About from "./../Pages/About";
import Contactus from "./../Pages/Contactus";
import LoginCompo from "./../Pages/LoginCompo.jsx";
import HeaderCompo from "./../Components/HeaderFile";
import Slider from "./../Components/Slider";

const MainRouter = createBrowserRouter([
    {
        path: "/",
        element: (
            <>
                <HeaderCompo />
                <Slider />
                <MainPage />
            </>
        ),
    }, {
        path: "/about",
        element: (
            <>
                <HeaderCompo />
                <About />
            </>
        ),
    }, {
        path: "/contact",
        element: (
            <>
                <HeaderCompo />
                <Contactus />
            </>
        ),
    }, {
        path: "/login",
        element: (
            <>
                <LoginCompo />
            </>
        ),
    }
])


export default MainRouter;